package com.example.npcbasketball.Models;

public enum TransactionType
{
    JERSEY, POSITION,
}
